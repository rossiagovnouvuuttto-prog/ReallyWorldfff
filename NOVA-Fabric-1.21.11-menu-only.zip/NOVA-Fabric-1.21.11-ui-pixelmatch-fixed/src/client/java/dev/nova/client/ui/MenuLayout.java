package dev.nova.client.ui;

import dev.nova.client.ui.component.Rect;

public final class MenuLayout {
    public final Rect window;
    public final Rect header;
    public final Rect sidebar;
    public final Rect content;
    public final Rect settings;
    public final Rect search;
    public final Rect gearButton;
    public final Rect closeButton;
    public final int padding;
    public final int gap;
    public final int rowHeight;

    private MenuLayout(
            Rect window,
            Rect header,
            Rect sidebar,
            Rect content,
            Rect settings,
            Rect search,
            Rect gearButton,
            Rect closeButton,
            int padding,
            int gap,
            int rowHeight
    ) {
        this.window = window;
        this.header = header;
        this.sidebar = sidebar;
        this.content = content;
        this.settings = settings;
        this.search = search;
        this.gearButton = gearButton;
        this.closeButton = closeButton;
        this.padding = padding;
        this.gap = gap;
        this.rowHeight = rowHeight;
    }

    public static MenuLayout compute(int screenWidth, int screenHeight, float requestedScale) {
        float scale = Math.max(0.75f, Math.min(1.25f, requestedScale));
        int outerMargin = screenWidth < 520 || screenHeight < 320 ? 6 : 12;
        int maxWidth = Math.max(1, screenWidth - outerMargin * 2);
        int maxHeight = Math.max(1, screenHeight - outerMargin * 2);

        int desiredWidth = Math.round(1036 * scale);
        int desiredHeight = Math.round(620 * scale);
        int windowWidth = Math.min(desiredWidth, maxWidth);
        int windowHeight = Math.min(desiredHeight, maxHeight);

        int x = (screenWidth - windowWidth) / 2;
        int y = (screenHeight - windowHeight) / 2;
        int padding = Math.max(10, Math.min(18, Math.round(16 * scale)));
        int gap = Math.max(8, Math.min(14, Math.round(12 * scale)));
        int headerHeight = Math.max(52, Math.min(78, Math.round(74 * scale)));

        Rect window = new Rect(x, y, windowWidth, windowHeight);
        Rect header = new Rect(x, y, windowWidth, headerHeight);

        int bodyY = y + headerHeight;
        int bodyHeight = Math.max(1, windowHeight - headerHeight - padding);
        int availableWidth = Math.max(1, windowWidth - padding * 2 - gap * 2);

        int sidebarWidth = Math.round(176 * scale);
        int settingsWidth = Math.round(324 * scale);

        int minSidebar = Math.min(120, Math.max(62, availableWidth / 5));
        int minSettings = Math.min(210, Math.max(118, availableWidth * 2 / 5));
        int minContent = Math.min(260, Math.max(48, availableWidth / 5));

        sidebarWidth = Math.max(minSidebar, Math.min(sidebarWidth, Math.max(minSidebar, availableWidth / 3)));
        settingsWidth = Math.max(minSettings, Math.min(settingsWidth, Math.max(minSettings, availableWidth / 2)));

        if (sidebarWidth + settingsWidth + minContent > availableWidth) {
            int overflow = sidebarWidth + settingsWidth + minContent - availableWidth;
            int reduceSettings = Math.min(overflow, Math.max(0, settingsWidth - minSettings));
            settingsWidth -= reduceSettings;
            overflow -= reduceSettings;
            if (overflow > 0) {
                sidebarWidth = Math.max(minSidebar, sidebarWidth - overflow);
            }
        }

        int contentWidth = Math.max(1, availableWidth - sidebarWidth - settingsWidth);
        int left = x + padding;

        Rect sidebar = new Rect(left, bodyY, sidebarWidth, bodyHeight);
        Rect content = new Rect(sidebar.right() + gap, bodyY, contentWidth, bodyHeight);
        Rect settings = new Rect(content.right() + gap, bodyY, settingsWidth, bodyHeight);

        int buttonSize = Math.max(30, Math.min(42, Math.round(36 * scale)));
        Rect closeButton = new Rect(x + windowWidth - padding - buttonSize, y + (headerHeight - buttonSize) / 2, buttonSize, buttonSize);
        Rect gearButton = new Rect(closeButton.x() - gap - buttonSize, closeButton.y(), buttonSize, buttonSize);

        int logoReserve = Math.max(130, Math.min(sidebarWidth + gap + 110, Math.round(248 * scale)));
        int searchRight = gearButton.x() - gap;
        int desiredSearchX = x + padding + logoReserve;
        int minimumSearchX = x + padding + 120;
        int searchX = Math.min(desiredSearchX, Math.max(minimumSearchX, searchRight - 140));
        int desiredSearchWidth = Math.round(500 * scale);
        int searchWidth = Math.max(120, Math.min(desiredSearchWidth, searchRight - searchX));
        int searchHeight = Math.max(28, Math.min(40, Math.round(36 * scale)));
        Rect search = new Rect(searchX, y + (headerHeight - searchHeight) / 2, searchWidth, searchHeight);

        int rowHeight = Math.max(42, Math.min(60, Math.round(56 * scale)));

        return new MenuLayout(
                window,
                header,
                sidebar,
                content,
                settings,
                search,
                gearButton,
                closeButton,
                padding,
                gap,
                rowHeight
        );
    }
}
