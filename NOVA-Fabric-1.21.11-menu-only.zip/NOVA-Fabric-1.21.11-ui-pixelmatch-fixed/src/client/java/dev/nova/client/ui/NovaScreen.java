package dev.nova.client.ui;

import dev.nova.client.NovaKeybinds;
import dev.nova.client.config.ConfigManager;
import dev.nova.client.config.NovaConfig;
import dev.nova.client.module.Category;
import dev.nova.client.module.ModuleRegistry;
import dev.nova.client.module.NovaModule;
import dev.nova.client.module.ToggleableNovaModule;
import dev.nova.client.theme.NovaTheme;
import dev.nova.client.ui.component.Rect;
import dev.nova.client.ui.component.UiRender;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Locale;

public final class NovaScreen extends Screen {
    private static final int WINDOW_RADIUS = 13;
    private static final int PANEL_RADIUS = 10;
    private static final float CATEGORY_TEXT_SCALE = 1.21f;
    private static final float MODULE_NAME_SCALE = 1.10f;
    private static final float SECTION_TITLE_SCALE = 1.17f;

    private Category selectedCategory = Category.COMBAT;
    private TextFieldWidget searchField;
    private MenuLayout layout;
    private String searchQuery = "";
    private float openProgress;
    private int sidebarScroll;
    private int contentScroll;
    private int settingsScroll;
    private boolean draggingScale;

    public NovaScreen() {
        super(Text.translatable("screen.nova_client.title"));
    }

    @Override
    protected void init() {
        String previousSearch = searchField == null ? searchQuery : searchField.getText();
        layout = MenuLayout.compute(width, height, ConfigManager.get().menuScale);
        createSearchField(previousSearch);
        clampScrolls();
    }

    private void createSearchField(String value) {
        int textX = layout.search.x() + 26;
        int textY = layout.search.y() + 3;
        int textWidth = Math.max(24, layout.search.width() - 36);
        int textHeight = Math.max(18, layout.search.height() - 6);

        searchField = new TextFieldWidget(
                textRenderer,
                textX,
                textY,
                textWidth,
                textHeight,
                Text.translatable("screen.nova_client.search")
        );
        searchField.setDrawsBackground(false);
        searchField.setEditableColor(NovaTheme.TEXT);
        searchField.setUneditableColor(NovaTheme.TEXT_MUTED);
        searchField.setTextShadow(false);
        searchField.setPlaceholder(Text.translatable("screen.nova_client.search"));
        searchField.setMaxLength(80);
        searchField.setText(value == null ? "" : value);
        searchQuery = searchField.getText();
        searchField.setChangedListener(text -> {
            searchQuery = text;
            contentScroll = 0;
        });
        addDrawableChild(searchField);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        NovaConfig config = ConfigManager.get();
        if (layout == null) {
            layout = MenuLayout.compute(width, height, config.menuScale);
        }

        if (!config.animations) {
            openProgress = 1.0f;
        } else {
            float step = Math.min(1.0f, 0.16f * Math.max(1.0f, deltaTicks));
            openProgress += (1.0f - openProgress) * step;
            if (openProgress > 0.995f) {
                openProgress = 1.0f;
            }
        }

        context.fill(0, 0, width, height, NovaTheme.withAlpha(NovaTheme.BACKDROP, 0.82f * openProgress));
        renderWindow(context, mouseX, mouseY);
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    private void renderWindow(DrawContext context, int mouseX, int mouseY) {
        NovaConfig config = ConfigManager.get();
        int accent = NovaTheme.argb(config.accentColor);
        Rect window = layout.window;

        UiRender.roundedRect(context, window.x() - 8, window.y() + 10, window.width() + 16, window.height() + 14,
                WINDOW_RADIUS + 5, NovaTheme.WINDOW_SHADOW);
        UiRender.roundedRect(context, window.x(), window.y(), window.width(), window.height(), WINDOW_RADIUS,
                0xB3161A26);
        UiRender.roundedRect(context, window.x() + 1, window.y() + 1, window.width() - 2, window.height() - 2,
                WINDOW_RADIUS - 1, NovaTheme.PANEL);
        UiRender.roundedRect(context, window.x() + 2, window.y() + 2, window.width() - 4, window.height() - 4,
                WINDOW_RADIUS - 2, withRgbAlpha(accent, 24));

        renderHeader(context, mouseX, mouseY, accent);
        renderCategories(context, mouseX, mouseY, accent);
        renderCenterPanel(context, mouseX, mouseY, accent);
        renderSettingsPanel(context, mouseX, mouseY, accent);
    }

    private void renderHeader(DrawContext context, int mouseX, int mouseY, int accent) {
        Rect window = layout.window;
        Rect search = layout.search;

        int logoX = window.x() + layout.padding + 10;
        int logoY = window.y() + (layout.header.height() - 28) / 2;
        renderNovaLogo(context, logoX, logoY, accent);

        UiRender.roundedRect(context, search.x(), search.y(), search.width(), search.height(), search.height() / 2,
                0xFF2C3146);
        UiRender.roundedRect(context, search.x() + 1, search.y() + 1, search.width() - 2, search.height() - 2,
                Math.max(1, search.height() / 2 - 1), 0xF3111420);
        renderSearchIcon(context, search.x() + 12, search.y() + search.height() / 2, NovaTheme.TEXT_MUTED);

        renderHeaderButton(context, layout.gearButton, "⚙", mouseX, mouseY, accent, false);
        renderHeaderButton(context, layout.closeButton, "×", mouseX, mouseY, accent, true);
    }

    private void renderSearchIcon(DrawContext context, int centerX, int centerY, int color) {
        UiRender.ring(context, centerX, centerY - 1, 4, 2, color, NovaTheme.PANEL_SECONDARY);
        context.fill(centerX + 3, centerY + 2, centerX + 7, centerY + 3, color);
        context.fill(centerX + 5, centerY + 3, centerX + 7, centerY + 5, color);
    }

    private void renderHeaderButton(DrawContext context, Rect rect, String symbol, int mouseX, int mouseY, int accent, boolean danger) {
        boolean hovered = rect.contains(mouseX, mouseY);
        int fill = hovered ? NovaTheme.PANEL_HOVER : 0xF3141722;
        UiRender.roundedRect(context, rect.x(), rect.y(), rect.width(), rect.height(), 8, fill);
        int color = hovered ? (danger ? 0xFFFF8A92 : accent) : NovaTheme.TEXT_MUTED;
        int textX = rect.x() + (rect.width() - textRenderer.getWidth(symbol)) / 2;
        int textY = rect.y() + (rect.height() - textRenderer.fontHeight) / 2;
        context.drawTextWithShadow(textRenderer, symbol, textX, textY, color);
    }

    private void renderCategories(DrawContext context, int mouseX, int mouseY, int accent) {
        Rect sidebar = layout.sidebar;
        int top = sidebar.y();
        int bottom = sidebar.bottom();
        int totalHeight = Category.values().length * (layout.rowHeight + 8) - 8;
        int maxScroll = Math.max(0, totalHeight - sidebar.height());
        sidebarScroll = UiRender.clamp(sidebarScroll, 0, maxScroll);

        context.enableScissor(sidebar.x(), top, sidebar.right(), bottom);
        int y = top - sidebarScroll;
        Category[] categories = Category.values();
        for (int i = 0; i < categories.length; i++) {
            Category category = categories[i];
            Rect row = new Rect(sidebar.x(), y, sidebar.width(), layout.rowHeight);
            boolean selected = category == selectedCategory;
            boolean hovered = row.contains(mouseX, mouseY) && mouseY >= top && mouseY < bottom;

            if (selected) {
                UiRender.roundedRect(context, row.x(), row.y(), row.width(), row.height(), 12, withRgbAlpha(accent, hovered ? 220 : 195));
                UiRender.roundedRect(context, row.x() + 2, row.y() + 2, row.width() - 4, row.height() - 4, 10, 0xF1161A26);
                UiRender.roundedRect(context, row.x() + 3, row.y() + 3, row.width() - 6, row.height() - 6, 10, withRgbAlpha(accent, 18));
            } else {
                UiRender.roundedRect(context, row.x(), row.y(), row.width(), row.height(), 12,
                        hovered ? NovaTheme.PANEL_HOVER : 0xF2141722);
            }

            int iconColor = selected ? NovaTheme.TEXT : NovaTheme.TEXT_MUTED;
            int iconCenterX = row.x() + 27;
            int iconCenterY = row.y() + row.height() / 2;
            renderCategoryIcon(context, i, iconCenterX, iconCenterY, iconColor);
            int labelX = row.x() + 48;
            int scaledH = Math.round(textRenderer.fontHeight * CATEGORY_TEXT_SCALE);
            int labelY = row.y() + (row.height() - scaledH) / 2;
            drawScaledText(context, category.displayName(), labelX, labelY,
                    selected ? NovaTheme.TEXT : NovaTheme.TEXT_MUTED, CATEGORY_TEXT_SCALE, true);

            y += layout.rowHeight + 8;
        }
        context.disableScissor();

        if (maxScroll > 0) {
            renderScrollbar(context, sidebar.right() - 3, top, sidebar.height(), totalHeight, sidebarScroll, maxScroll, accent);
        }
    }

    private void renderCenterPanel(DrawContext context, int mouseX, int mouseY, int accent) {
        Rect panel = layout.content;
        UiRender.roundedRect(context, panel.x(), panel.y(), panel.width(), panel.height(), PANEL_RADIUS, 0xFF202433);
        UiRender.roundedRect(context, panel.x() + 1, panel.y() + 1, panel.width() - 2, panel.height() - 2,
                PANEL_RADIUS - 1, 0xF3111520);

        int left = panel.x() + layout.padding;
        int top = panel.y() + layout.padding;
        int right = panel.right() - layout.padding;
        int bottom = panel.bottom() - layout.padding;
        int viewportWidth = Math.max(1, right - left);
        int viewportHeight = Math.max(1, bottom - top);

        context.enableScissor(left, top, right, bottom);
        renderModules(context, mouseX, mouseY, accent, left, top, viewportWidth, viewportHeight);
        context.disableScissor();
    }

    private void renderModules(DrawContext context, int mouseX, int mouseY, int accent, int left, int top, int width, int height) {
        List<NovaModule> modules = ModuleRegistry.find(selectedCategory, searchQuery);
        if (selectedCategory == Category.SETTINGS) {
            modules = List.of();
        }

        if (modules.isEmpty()) {
            Text message = searchQuery.isBlank()
                    ? Text.translatable("screen.nova_client.empty")
                    : Text.translatable("screen.nova_client.no_results");
            int centerX = left + width / 2;
            int centerY = top + height / 2;
            renderCubeIcon(context, centerX, centerY - 26, NovaTheme.TEXT_DIM);
            drawScaledCenteredText(context, message, centerX, centerY + 24, NovaTheme.TEXT_MUTED, 1.10f, true);
            contentScroll = 0;
            return;
        }

        int cardHeight = 68;
        int gap = 10;
        int totalHeight = modules.size() * (cardHeight + gap) - gap;
        int maxScroll = Math.max(0, totalHeight - height);
        contentScroll = UiRender.clamp(contentScroll, 0, maxScroll);
        int y = top - contentScroll;

        for (NovaModule module : modules) {
            Rect card = new Rect(left, y, width - (maxScroll > 0 ? 7 : 0), cardHeight);
            boolean hovered = card.contains(mouseX, mouseY) && mouseY >= top && mouseY < top + height;
            UiRender.roundedRect(context, card.x(), card.y(), card.width(), card.height(), 10,
                    hovered ? NovaTheme.PANEL_HOVER : 0xF31A1E2A);

            int textY = card.y() + 12;
            drawScaledText(context, module.name(), card.x() + 13, textY, NovaTheme.TEXT, MODULE_NAME_SCALE, true);
            context.drawText(textRenderer, module.description(), card.x() + 13, card.y() + 39, NovaTheme.TEXT_MUTED, false);

            if (module instanceof ToggleableNovaModule toggleable) {
                int toggleWidth = 40;
                int toggleHeight = 22;
                int toggleX = card.right() - toggleWidth - 13;
                int toggleY = card.y() + 10;
                int track = toggleable.isEnabled() ? withRgbAlpha(accent, 220) : NovaTheme.BORDER;
                UiRender.roundedRect(context, toggleX, toggleY, toggleWidth, toggleHeight, 10, track);
                int knob = toggleHeight - 4;
                int knobX = toggleable.isEnabled() ? toggleX + toggleWidth - knob - 2 : toggleX + 2;
                UiRender.roundedRect(context, knobX, toggleY + 2, knob, knob, knob / 2, 0xFFF7F7FB);
            }
            y += cardHeight + gap;
        }

        if (maxScroll > 0) {
            renderScrollbar(context, left + width - 3, top, height, totalHeight, contentScroll, maxScroll, accent);
        }
    }

    private void renderSettingsPanel(DrawContext context, int mouseX, int mouseY, int accent) {
        Rect panel = layout.settings;
        UiRender.roundedRect(context, panel.x(), panel.y(), panel.width(), panel.height(), PANEL_RADIUS, 0xFF202433);
        UiRender.roundedRect(context, panel.x() + 1, panel.y() + 1, panel.width() - 2, panel.height() - 2,
                PANEL_RADIUS - 1, 0xF3111520);

        int clipLeft = panel.x() + 1;
        int clipTop = panel.y() + 1;
        int clipRight = panel.right() - 1;
        int clipBottom = panel.bottom() - 1;
        SettingsMetrics metrics = settingsMetrics();
        int maxScroll = Math.max(0, metrics.totalHeight - Math.max(1, panel.height() - layout.padding * 2));
        settingsScroll = UiRender.clamp(settingsScroll, 0, maxScroll);
        metrics = settingsMetrics();

        context.enableScissor(clipLeft, clipTop, clipRight, clipBottom);
        renderSettingsContent(context, mouseX, mouseY, accent, metrics);
        context.disableScissor();

        if (maxScroll > 0) {
            renderScrollbar(context, panel.right() - 4, panel.y() + layout.padding,
                    panel.height() - layout.padding * 2, metrics.totalHeight, settingsScroll, maxScroll, accent);
        }
    }

    private void renderSettingsContent(DrawContext context, int mouseX, int mouseY, int accent, SettingsMetrics m) {
        NovaConfig config = ConfigManager.get();

        drawScaledText(context, Text.translatable("screen.nova_client.settings_menu"),
                m.left, m.titleY, NovaTheme.TEXT, SECTION_TITLE_SCALE, true);

        context.drawText(textRenderer, Text.translatable("screen.nova_client.accent"), m.left, m.accentLabelY,
                0xFFC8C9D8, false);
        renderAccentSwatches(context, m, config.accentColor, mouseX, mouseY);

        String percent = String.format(Locale.ROOT, "%.0f%%", config.menuScale * 100.0f);
        context.drawText(textRenderer, Text.translatable("screen.nova_client.scale"), m.left, m.scaleLabelY,
                0xFFC8C9D8, false);
        context.drawText(textRenderer, percent, m.right - textRenderer.getWidth(percent), m.scaleLabelY,
                NovaTheme.TEXT_MUTED, false);
        renderScaleControl(context, m.scaleTrack, config.menuScale, accent, mouseX, mouseY);

        context.drawText(textRenderer, Text.translatable("screen.nova_client.animations"), m.left, m.animationLabelY,
                0xFFC8C9D8, false);
        renderToggle(context, m.animationToggle, config.animations, accent, mouseX, mouseY);

        context.fill(m.left, m.dividerY, m.right, m.dividerY + 1, 0xFF232739);
        drawScaledText(context, Text.translatable("screen.nova_client.controls"),
                m.left, m.controlsTitleY, NovaTheme.TEXT, SECTION_TITLE_SCALE, true);

        renderBindingRow(context, m.openMenuRow, Text.translatable("screen.nova_client.open_menu"),
                NovaKeybinds.openMenuKeyText());

        boolean resetHovered = m.resetButton.contains(mouseX, mouseY);
        UiRender.roundedRect(context, m.resetButton.x(), m.resetButton.y(), m.resetButton.width(), m.resetButton.height(), 8,
                resetHovered ? NovaTheme.PANEL_HOVER : 0xFF4B4F66);
        Text reset = Text.translatable("screen.nova_client.reset");
        int resetX = m.resetButton.x() + (m.resetButton.width() - textRenderer.getWidth(reset)) / 2;
        int resetY = m.resetButton.y() + (m.resetButton.height() - textRenderer.fontHeight) / 2;
        context.drawTextWithShadow(textRenderer, reset, resetX, resetY, resetHovered ? accent : NovaTheme.TEXT);
    }

    private void renderAccentSwatches(DrawContext context, SettingsMetrics m, int currentRgb, int mouseX, int mouseY) {
        for (int i = 0; i < NovaTheme.ACCENTS.length; i++) {
            int col = i % m.swatchColumns;
            int row = i / m.swatchColumns;
            int centerX = m.left + m.swatchRadius + col * (m.swatchRadius * 2 + m.swatchGap);
            int centerY = m.swatchesTop + m.swatchRadius + row * (m.swatchRadius * 2 + m.swatchGap);
            int color = NovaTheme.argb(NovaTheme.ACCENTS[i]);
            int hitRadius = m.swatchRadius + 3;
            boolean hovered = mouseX >= centerX - hitRadius && mouseX <= centerX + hitRadius
                    && mouseY >= centerY - hitRadius && mouseY <= centerY + hitRadius;
            boolean selected = (currentRgb & 0xFFFFFF) == NovaTheme.ACCENTS[i];

            if (selected || hovered) {
                UiRender.ring(context, centerX, centerY, m.swatchRadius + 3, m.swatchRadius + 1,
                        selected ? color : 0x55FFFFFF, NovaTheme.PANEL_SECONDARY);
            }
            UiRender.circle(context, centerX, centerY, m.swatchRadius, color);
        }
    }

    private void renderScaleControl(DrawContext context, Rect track, float scale, int accent, int mouseX, int mouseY) {
        UiRender.roundedRect(context, track.x(), track.y(), track.width(), track.height(), track.height() / 2, NovaTheme.BORDER);
        float t = (scale - NovaConfig.MIN_SCALE) / (NovaConfig.MAX_SCALE - NovaConfig.MIN_SCALE);
        int fillWidth = Math.max(track.height(), Math.round(track.width() * t));
        UiRender.roundedRect(context, track.x(), track.y(), fillWidth, track.height(), track.height() / 2, accent);
        int knobX = track.x() + Math.round(track.width() * t);
        int knobRadius = 6;
        UiRender.circle(context, knobX, track.y() + track.height() / 2, knobRadius,
                track.contains(mouseX, mouseY) ? 0xFFFFFFFF : 0xFFE2D8FF);
    }

    private void renderToggle(DrawContext context, Rect toggle, boolean enabled, int accent, int mouseX, int mouseY) {
        int trackColor = enabled ? withRgbAlpha(accent, 225) : NovaTheme.BORDER;
        UiRender.roundedRect(context, toggle.x(), toggle.y(), toggle.width(), toggle.height(), toggle.height() / 2, trackColor);
        int knobSize = toggle.height() - 4;
        int knobX = enabled ? toggle.right() - knobSize - 2 : toggle.x() + 2;
        UiRender.roundedRect(context, knobX, toggle.y() + 2, knobSize, knobSize, knobSize / 2, 0xFFF8F8FC);
        if (toggle.contains(mouseX, mouseY)) {
            UiRender.roundedRect(context, toggle.x() - 2, toggle.y() - 2, toggle.width() + 4, toggle.height() + 4,
                    toggle.height() / 2 + 2, 0x22FFFFFF);
        }
    }

    private void renderBindingRow(DrawContext context, Rect row, Text label, Text key) {
        int textY = row.y() + (row.height() - textRenderer.fontHeight) / 2;

        int keyWidth = Math.max(44, textRenderer.getWidth(key) + 18);
        keyWidth = Math.min(keyWidth, Math.max(44, row.width() / 2 - 2));
        int labelWidth = Math.max(0, row.width() - keyWidth - 8);
        String labelText = textRenderer.trimToWidth(label.getString(), labelWidth);
        context.drawText(textRenderer, labelText, row.x(), textY, 0xFFC8C9D8, false);

        Rect pill = new Rect(row.right() - keyWidth, row.y() + 3, keyWidth, row.height() - 6);
        UiRender.roundedRect(context, pill.x(), pill.y(), pill.width(), pill.height(), 7, 0xF323283A);
        int keyX = pill.x() + (pill.width() - textRenderer.getWidth(key)) / 2;
        int keyY = pill.y() + (pill.height() - textRenderer.fontHeight) / 2;
        context.drawText(textRenderer, key, keyX, keyY, NovaTheme.TEXT, false);
    }

    private void renderScrollbar(DrawContext context, int x, int y, int viewportHeight, int totalHeight, int scroll, int maxScroll, int accent) {
        int thumbHeight = Math.max(16, Math.round(viewportHeight * (viewportHeight / (float) Math.max(1, totalHeight))));
        int travel = Math.max(1, viewportHeight - thumbHeight);
        int thumbY = y + Math.round(travel * (scroll / (float) Math.max(1, maxScroll)));
        UiRender.roundedRect(context, x, y, 2, viewportHeight, 1, 0x44383A4C);
        UiRender.roundedRect(context, x - 1, thumbY, 4, thumbHeight, 2, accent);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) {
            return true;
        }
        if (click.button() != GLFW.GLFW_MOUSE_BUTTON_LEFT || layout == null) {
            return false;
        }

        double mouseX = click.x();
        double mouseY = click.y();

        if (layout.closeButton.contains(mouseX, mouseY)) {
            close();
            return true;
        }
        if (layout.gearButton.contains(mouseX, mouseY)) {
            selectedCategory = Category.SETTINGS;
            contentScroll = 0;
            settingsScroll = 0;
            return true;
        }

        Category clickedCategory = categoryAt(mouseX, mouseY);
        if (clickedCategory != null) {
            selectedCategory = clickedCategory;
            contentScroll = 0;
            return true;
        }

        if (handleSettingsClick(mouseX, mouseY)) {
            return true;
        }

        NovaModule module = moduleAt(mouseX, mouseY);
        if (module instanceof ToggleableNovaModule toggleable) {
            toggleable.toggle();
            return true;
        }

        return false;
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (click.button() == GLFW.GLFW_MOUSE_BUTTON_LEFT && draggingScale) {
            Rect track = settingsMetrics().scaleTrack;
            setScaleFromMouse(click.x(), track);
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        draggingScale = false;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (layout != null && layout.sidebar.contains(mouseX, mouseY)) {
            sidebarScroll -= (int) Math.round(verticalAmount * 20.0);
            clampScrolls();
            return true;
        }
        if (layout != null && layout.content.contains(mouseX, mouseY)) {
            contentScroll -= (int) Math.round(verticalAmount * 24.0);
            clampScrolls();
            return true;
        }
        if (layout != null && layout.settings.contains(mouseX, mouseY)) {
            settingsScroll -= (int) Math.round(verticalAmount * 24.0);
            clampScrolls();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.isEscape()) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private Category categoryAt(double mouseX, double mouseY) {
        Rect sidebar = layout.sidebar;
        if (!sidebar.contains(mouseX, mouseY)) {
            return null;
        }

        int y = sidebar.y() - sidebarScroll;
        for (Category category : Category.values()) {
            Rect row = new Rect(sidebar.x(), y, sidebar.width(), layout.rowHeight);
            if (row.contains(mouseX, mouseY)) {
                return category;
            }
            y += layout.rowHeight + 8;
        }
        return null;
    }

    private NovaModule moduleAt(double mouseX, double mouseY) {
        if (selectedCategory == Category.SETTINGS) {
            return null;
        }
        Rect panel = layout.content;
        int left = panel.x() + layout.padding;
        int top = panel.y() + layout.padding;
        int right = panel.right() - layout.padding;
        int bottom = panel.bottom() - layout.padding;
        if (mouseX < left || mouseX >= right || mouseY < top || mouseY >= bottom) {
            return null;
        }

        List<NovaModule> modules = ModuleRegistry.find(selectedCategory, searchQuery);
        int cardHeight = 68;
        int gap = 10;
        int viewportHeight = Math.max(1, bottom - top);
        int totalHeight = modules.isEmpty() ? 0 : modules.size() * (cardHeight + gap) - gap;
        int maxScroll = Math.max(0, totalHeight - viewportHeight);
        int cardWidth = Math.max(1, right - left - (maxScroll > 0 ? 7 : 0));
        int y = top - contentScroll;
        for (NovaModule module : modules) {
            Rect card = new Rect(left, y, cardWidth, cardHeight);
            if (card.contains(mouseX, mouseY)) {
                return module;
            }
            y += cardHeight + gap;
        }
        return null;
    }

    private boolean handleSettingsClick(double mouseX, double mouseY) {
        if (!layout.settings.contains(mouseX, mouseY)) {
            return false;
        }

        SettingsMetrics m = settingsMetrics();
        for (int i = 0; i < NovaTheme.ACCENTS.length; i++) {
            int col = i % m.swatchColumns;
            int row = i / m.swatchColumns;
            int centerX = m.left + m.swatchRadius + col * (m.swatchRadius * 2 + m.swatchGap);
            int centerY = m.swatchesTop + m.swatchRadius + row * (m.swatchRadius * 2 + m.swatchGap);
            int hit = m.swatchRadius + 4;
            if (mouseX >= centerX - hit && mouseX <= centerX + hit && mouseY >= centerY - hit && mouseY <= centerY + hit) {
                ConfigManager.get().accentColor = NovaTheme.ACCENTS[i];
                ConfigManager.save();
                return true;
            }
        }

        Rect scaleHit = new Rect(m.scaleTrack.x() - 6, m.scaleTrack.y() - 8,
                m.scaleTrack.width() + 12, m.scaleTrack.height() + 16);
        if (scaleHit.contains(mouseX, mouseY)) {
            draggingScale = true;
            setScaleFromMouse(mouseX, m.scaleTrack);
            return true;
        }

        Rect animationHit = new Rect(m.left, m.animationLabelY - 6, m.right - m.left,
                Math.max(28, m.animationToggle.bottom() - m.animationLabelY + 8));
        if (animationHit.contains(mouseX, mouseY)) {
            ConfigManager.get().animations = !ConfigManager.get().animations;
            ConfigManager.save();
            return true;
        }

        if (m.resetButton.contains(mouseX, mouseY)) {
            ConfigManager.resetToDefaults();
            settingsScroll = 0;
            rebuildLayoutKeepingSearch();
            return true;
        }
        return false;
    }

    private void setScaleFromMouse(double mouseX, Rect track) {
        double t = Math.max(0.0, Math.min(1.0, (mouseX - track.x()) / Math.max(1.0, track.width())));
        NovaConfig config = ConfigManager.get();
        config.menuScale = NovaConfig.MIN_SCALE + (float) t * (NovaConfig.MAX_SCALE - NovaConfig.MIN_SCALE);
        ConfigManager.save();
        rebuildLayoutKeepingSearch();
        draggingScale = true;
    }

    private void rebuildLayoutKeepingSearch() {
        String value = searchField == null ? searchQuery : searchField.getText();
        clearChildren();
        layout = MenuLayout.compute(width, height, ConfigManager.get().menuScale);
        createSearchField(value);
        clampScrolls();
    }

    private SettingsMetrics settingsMetrics() {
        Rect panel = layout.settings;
        int visibleTop = panel.y() + layout.padding;
        int left = panel.x() + layout.padding;
        int right = panel.right() - layout.padding;
        int innerWidth = Math.max(1, right - left);
        int y = visibleTop - settingsScroll;

        int titleY = y + 2;
        y += 38;

        int accentLabelY = y;
        y += 22;

        int swatchColumns = innerWidth >= 180 ? 8 : 4;
        int swatchRows = (NovaTheme.ACCENTS.length + swatchColumns - 1) / swatchColumns;
        int swatchGap = innerWidth >= 180 ? 8 : 8;
        int maxRadiusFromWidth = Math.max(4, (innerWidth - (swatchColumns - 1) * swatchGap) / (swatchColumns * 2));
        int swatchRadius = Math.min(7, maxRadiusFromWidth);
        int swatchesTop = y;
        y += swatchRows * (swatchRadius * 2 + swatchGap) - swatchGap;
        y += 24;

        int scaleLabelY = y;
        y += 22;
        Rect scaleTrack = new Rect(left, y, innerWidth, 8);
        y += 34;

        int animationLabelY = y;
        Rect animationToggle = new Rect(Math.max(left, right - 44), y - 6, 44, 24);
        y += 40;

        int dividerY = y;
        y += 18;
        int controlsTitleY = y;
        y += 28;

        Rect openMenuRow = new Rect(left, y, innerWidth, 30);
        y += 42;

        Rect resetButton = new Rect(left, y, innerWidth, 44);
        y += 42;

        int totalHeight = y - (visibleTop - settingsScroll);
        return new SettingsMetrics(
                left,
                right,
                titleY,
                accentLabelY,
                swatchesTop,
                swatchColumns,
                swatchRadius,
                swatchGap,
                scaleLabelY,
                scaleTrack,
                animationLabelY,
                animationToggle,
                dividerY,
                controlsTitleY,
                openMenuRow,
                resetButton,
                totalHeight
        );
    }

    private void clampScrolls() {
        if (layout == null) {
            return;
        }

        int sidebarTotal = Category.values().length * (layout.rowHeight + 8) - 8;
        sidebarScroll = UiRender.clamp(sidebarScroll, 0, Math.max(0, sidebarTotal - layout.sidebar.height()));

        int contentAvailable = Math.max(1, layout.content.height() - layout.padding * 2);
        int count = selectedCategory == Category.SETTINGS ? 0 : ModuleRegistry.find(selectedCategory, searchQuery).size();
        int contentTotal = count == 0 ? 0 : count * 78 - 10;
        contentScroll = UiRender.clamp(contentScroll, 0, Math.max(0, contentTotal - contentAvailable));

        SettingsMetrics m = settingsMetrics();
        int settingsAvailable = Math.max(1, layout.settings.height() - layout.padding * 2);
        settingsScroll = UiRender.clamp(settingsScroll, 0, Math.max(0, m.totalHeight - settingsAvailable));
    }

    private void renderNovaLogo(DrawContext context, int x, int y, int accent) {
        int bright = 0xFFC6A6FF;
        int t = 4;
        int h = 28;
        int w = 18;
        int gap = 6;
        int c = accent;

        // N
        context.fill(x, y, x + t, y + h, c);
        context.fill(x + w - t, y, x + w, y + h, bright);
        for (int i = 0; i < h - 2; i += 3) {
            int dx = Math.min(w - t, Math.round(i * (w - t) / (float) h));
            context.fill(x + dx, y + i, x + dx + t, y + Math.min(h, i + 4), c);
        }

        x += w + gap;
        // O
        context.fill(x + t, y, x + w - t, y + t, bright);
        context.fill(x + t, y + h - t, x + w - t, y + h, c);
        context.fill(x, y + t, x + t, y + h - t, c);
        context.fill(x + w - t, y + t, x + w, y + h - t, bright);

        x += w + gap;
        // V
        for (int i = 0; i < h - 5; i += 3) {
            int inset = Math.round(i * 5f / h);
            context.fill(x + inset, y + i, x + inset + t, y + i + 4, c);
            context.fill(x + w - inset - t, y + i, x + w - inset, y + i + 4, bright);
        }
        context.fill(x + 5, y + h - 6, x + 9, y + h, c);

        x += w + gap;
        // A
        context.fill(x + 1, y + 5, x + 1 + t, y + h, c);
        context.fill(x + w - t - 1, y + 5, x + w - 1, y + h, bright);
        context.fill(x + 4, y, x + w - 4, y + t, bright);
        context.fill(x + 3, y + 10, x + w - 3, y + 13, c);
    }


    private void renderCategoryIcon(DrawContext context, int categoryIndex, int centerX, int centerY, int color) {
        switch (categoryIndex) {
            case 0 -> renderSwordIcon(context, centerX, centerY, color);
            case 1 -> renderMovementIcon(context, centerX, centerY, color);
            case 2 -> renderEyeIcon(context, centerX, centerY, color);
            case 3 -> renderPlayerIcon(context, centerX, centerY, color);
            case 4 -> renderGridIcon(context, centerX, centerY, color);
            default -> renderGearIcon(context, centerX, centerY, color);
        }
    }

    private void renderSwordIcon(DrawContext context, int cx, int cy, int color) {
        drawLine(context, cx - 5, cy + 6, cx + 5, cy - 4, color, 2);
        drawLine(context, cx - 2, cy + 1, cx + 3, cy + 6, color, 2);
        context.fill(cx + 3, cy - 6, cx + 5, cy - 3, color);
        context.fill(cx - 6, cy + 5, cx - 2, cy + 7, color);
    }

    private void renderMovementIcon(DrawContext context, int cx, int cy, int color) {
        UiRender.circle(context, cx, cy - 6, 2, color);
        drawLine(context, cx, cy - 3, cx - 1, cy + 1, color, 2);
        drawLine(context, cx - 1, cy + 1, cx + 4, cy + 3, color, 2);
        drawLine(context, cx, cy - 1, cx + 4, cy - 4, color, 2);
        drawLine(context, cx - 1, cy + 1, cx - 5, cy + 7, color, 2);
        drawLine(context, cx + 2, cy + 2, cx + 7, cy + 7, color, 2);
    }

    private void renderEyeIcon(DrawContext context, int cx, int cy, int color) {
        drawLine(context, cx - 8, cy, cx - 4, cy - 4, color, 2);
        drawLine(context, cx - 4, cy - 4, cx + 4, cy - 4, color, 2);
        drawLine(context, cx + 4, cy - 4, cx + 8, cy, color, 2);
        drawLine(context, cx - 8, cy, cx - 4, cy + 4, color, 2);
        drawLine(context, cx - 4, cy + 4, cx + 4, cy + 4, color, 2);
        drawLine(context, cx + 4, cy + 4, cx + 8, cy, color, 2);
        UiRender.circle(context, cx, cy, 2, color);
    }

    private void renderPlayerIcon(DrawContext context, int cx, int cy, int color) {
        UiRender.circle(context, cx, cy - 5, 3, color);
        UiRender.roundedRect(context, cx - 6, cy, 12, 8, 4, color);
    }

    private void renderGridIcon(DrawContext context, int cx, int cy, int color) {
        int s = 4;
        context.fill(cx - 8, cy - 8, cx - 8 + s, cy - 8 + s, color);
        context.fill(cx + 1, cy - 8, cx + 1 + s, cy - 8 + s, color);
        context.fill(cx - 8, cy + 1, cx - 8 + s, cy + 1 + s, color);
        context.fill(cx + 1, cy + 1, cx + 1 + s, cy + 1 + s, color);
    }

    private void renderGearIcon(DrawContext context, int cx, int cy, int color) {
        UiRender.circle(context, cx, cy, 5, color);
        UiRender.circle(context, cx, cy, 2, 0xF3111520);
        context.fill(cx - 1, cy - 10, cx + 1, cy - 6, color);
        context.fill(cx - 1, cy + 6, cx + 1, cy + 10, color);
        context.fill(cx - 10, cy - 1, cx - 6, cy + 1, color);
        context.fill(cx + 6, cy - 1, cx + 10, cy + 1, color);
        context.fill(cx - 7, cy - 7, cx - 4, cy - 4, color);
        context.fill(cx + 4, cy - 7, cx + 7, cy - 4, color);
        context.fill(cx - 7, cy + 4, cx - 4, cy + 7, color);
        context.fill(cx + 4, cy + 4, cx + 7, cy + 7, color);
    }

    private void renderCubeIcon(DrawContext context, int centerX, int centerY, int color) {
        int s = 19;
        int topY = centerY - 15;
        int midY = centerY - 5;
        int bottomY = centerY + 14;
        drawLine(context, centerX, topY, centerX - s, midY, color, 2);
        drawLine(context, centerX, topY, centerX + s, midY, color, 2);
        drawLine(context, centerX - s, midY, centerX, midY + 9, color, 2);
        drawLine(context, centerX + s, midY, centerX, midY + 9, color, 2);
        drawLine(context, centerX - s, midY, centerX - s, bottomY, color, 2);
        drawLine(context, centerX + s, midY, centerX + s, bottomY, color, 2);
        drawLine(context, centerX - s, bottomY, centerX, bottomY + 9, color, 2);
        drawLine(context, centerX + s, bottomY, centerX, bottomY + 9, color, 2);
        drawLine(context, centerX, midY + 9, centerX, bottomY + 9, color, 2);
    }

    private void drawLine(DrawContext context, int x0, int y0, int x1, int y1, int color, int thickness) {
        int dx = Math.abs(x1 - x0);
        int sx = x0 < x1 ? 1 : -1;
        int dy = -Math.abs(y1 - y0);
        int sy = y0 < y1 ? 1 : -1;
        int err = dx + dy;
        int r = Math.max(0, thickness / 2);
        while (true) {
            context.fill(x0 - r, y0 - r, x0 + r + 1, y0 + r + 1, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    private void drawScaledText(DrawContext context, Text text, int x, int y, int color, float scale, boolean shadow) {
        var matrices = context.getMatrices();
        matrices.pushMatrix();
        matrices.translate(x, y);
        matrices.scale(scale, scale);
        context.drawText(textRenderer, text, 0, 0, color, shadow);
        matrices.popMatrix();
    }

    private void drawScaledCenteredText(DrawContext context, Text text, int centerX, int y, int color, float scale, boolean shadow) {
        int width = Math.round(textRenderer.getWidth(text) * scale);
        drawScaledText(context, text, centerX - width / 2, y, color, scale, shadow);
    }

    private static int withRgbAlpha(int argb, int alpha) {
        return ((alpha & 0xFF) << 24) | (argb & 0x00FFFFFF);
    }

    private record SettingsMetrics(
            int left,
            int right,
            int titleY,
            int accentLabelY,
            int swatchesTop,
            int swatchColumns,
            int swatchRadius,
            int swatchGap,
            int scaleLabelY,
            Rect scaleTrack,
            int animationLabelY,
            Rect animationToggle,
            int dividerY,
            int controlsTitleY,
            Rect openMenuRow,
            Rect resetButton,
            int totalHeight
    ) {
    }
}
