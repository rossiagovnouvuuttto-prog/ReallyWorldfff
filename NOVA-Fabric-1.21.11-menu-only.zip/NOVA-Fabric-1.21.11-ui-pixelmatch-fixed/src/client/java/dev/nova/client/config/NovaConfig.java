package dev.nova.client.config;

public final class NovaConfig {
    public static final int DEFAULT_ACCENT = 0x8B5CF6;
    public static final float MIN_SCALE = 0.75f;
    public static final float MAX_SCALE = 1.25f;

    public int accentColor = DEFAULT_ACCENT;
    public float menuScale = 1.0f;
    public boolean animations = true;

    public void sanitize() {
        accentColor &= 0x00FFFFFF;
        if (!Float.isFinite(menuScale)) {
            menuScale = 1.0f;
        }
        menuScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, menuScale));
    }
}
