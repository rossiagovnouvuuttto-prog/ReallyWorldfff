package dev.nova.client.theme;

public final class NovaTheme {
    public static final int BACKDROP = 0xC90A0B10;
    public static final int WINDOW_SHADOW = 0x9E000000;
    public static final int PANEL = 0xF7080A10;
    public static final int PANEL_SECONDARY = 0xF3121520;
    public static final int PANEL_TERTIARY = 0xF41A1E2A;
    public static final int PANEL_HOVER = 0xF7283040;
    public static final int TEXT = 0xFFF4F4F8;
    public static final int TEXT_MUTED = 0xFFB7B8D0;
    public static final int TEXT_DIM = 0xFF696B84;
    public static final int BORDER = 0xFF2C3146;
    public static final int BORDER_SOFT = 0xFF202433;

    public static final int[] ACCENTS = {
            0x8B5CF6,
            0x4F7CFF,
            0x35C9ED,
            0x31D981,
            0xE8D447,
            0xFFAD3D,
            0xFF5E55,
            0xF64F96
    };

    private NovaTheme() {
    }

    public static int argb(int rgb) {
        return 0xFF000000 | (rgb & 0x00FFFFFF);
    }

    public static int withAlpha(int color, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(((color >>> 24) & 0xFF) * alpha)));
        return (a << 24) | (color & 0x00FFFFFF);
    }
}
