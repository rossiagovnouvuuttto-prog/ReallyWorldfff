package dev.nova.client;

import dev.nova.client.ui.NovaScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class NovaKeybinds {
    public static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of("nova_client", "controls"));

    private static final KeyBinding OPEN_MENU = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.nova_client.open_menu",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            CATEGORY
    ));

    private NovaKeybinds() {
    }

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_MENU.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new NovaScreen());
                }
            }
        });
    }

    public static Text openMenuKeyText() {
        return OPEN_MENU.getBoundKeyLocalizedText();
    }
}
