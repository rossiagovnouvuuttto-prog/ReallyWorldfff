package dev.nova.client.ui.component;

import net.minecraft.client.gui.DrawContext;

public final class UiRender {
    private UiRender() {
    }

    public static void roundedRect(DrawContext context, int x, int y, int width, int height, int radius, int color) {
        if (width <= 0 || height <= 0) {
            return;
        }
        int r = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
        if (r == 0) {
            context.fill(x, y, x + width, y + height, color);
            return;
        }

        context.fill(x + r, y, x + width - r, y + height, color);
        context.fill(x, y + r, x + width, y + height - r, color);

        for (int dy = 0; dy < r; dy++) {
            double yy = r - dy - 0.5;
            int dx = (int) Math.floor(Math.sqrt(Math.max(0.0, r * r - yy * yy)));
            int left = x + r - dx;
            int right = x + width - r + dx;
            context.fill(left, y + dy, right, y + dy + 1, color);
            context.fill(left, y + height - dy - 1, right, y + height - dy, color);
        }
    }

    public static void roundedOutline(DrawContext context, int x, int y, int width, int height, int radius, int thickness, int color) {
        if (width <= 0 || height <= 0 || thickness <= 0) {
            return;
        }
        roundedRect(context, x, y, width, height, radius, color);
        int innerWidth = width - thickness * 2;
        int innerHeight = height - thickness * 2;
        if (innerWidth > 0 && innerHeight > 0) {
            roundedRect(context, x + thickness, y + thickness, innerWidth, innerHeight,
                    Math.max(0, radius - thickness), 0x00000000);
        }
    }

    public static void ring(DrawContext context, int centerX, int centerY, int outerRadius, int innerRadius, int color, int innerColor) {
        circle(context, centerX, centerY, outerRadius, color);
        if (innerRadius > 0) {
            circle(context, centerX, centerY, innerRadius, innerColor);
        }
    }

    public static void circle(DrawContext context, int centerX, int centerY, int radius, int color) {
        if (radius <= 0) {
            context.fill(centerX, centerY, centerX + 1, centerY + 1, color);
            return;
        }
        for (int dy = -radius; dy <= radius; dy++) {
            int dx = (int) Math.floor(Math.sqrt(Math.max(0, radius * radius - dy * dy)));
            context.fill(centerX - dx, centerY + dy, centerX + dx + 1, centerY + dy + 1, color);
        }
    }

    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
